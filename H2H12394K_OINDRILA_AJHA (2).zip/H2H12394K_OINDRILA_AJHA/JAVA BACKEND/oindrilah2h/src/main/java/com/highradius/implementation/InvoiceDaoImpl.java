//package com.highradius.implementation;
//import com.highradius.connection.DatabaseConnection;
//import com.highradius.model.Invoice;
//
//import java.util.List;
//
//public class InvoiceDaoImpl {
//    private DatabaseConnection dbconn = new DatabaseConnection();
//
//    public void insertInvoice (Invoice invoice){
//        dbconn.addInvoices(invoice);
//    }
//    public List<Invoice> getInvoice (){
//        return dbconn.getInvoices();
//    }
//}
